#!/bin/bash

python main_custom.py --save_dir=T_V_baseline2 --gpu=0 --source_domain=T --target_domain=V --dataset=visda2017 --baseline2
python main_custom.py --save_dir=V_T_baseline2 --gpu=0 --source_domain=V --target_domain=T --dataset=visda2017 --baseline2
