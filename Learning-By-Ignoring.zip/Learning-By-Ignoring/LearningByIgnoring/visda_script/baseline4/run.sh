#!/bin/bash

python main_custom.py --save_dir=T_V_baseline4 --gpu=0 --source_domain=T --target_domain=V --dataset=visda2017 --baseline4 --lam=5e-4
python main_custom.py --save_dir=V_T_baseline4 --gpu=0 --source_domain=V --target_domain=T --dataset=visda2017 --baseline4 --lam=5e-4
