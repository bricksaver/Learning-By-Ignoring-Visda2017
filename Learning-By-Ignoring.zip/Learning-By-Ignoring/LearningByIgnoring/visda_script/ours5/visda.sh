#!/bin/bash

python main_custom.py --save_dir=T_V_ours5 --gpu=0 --source_domain=T --target_domain=V --dataset=visda2017 --ours5 --lam=5e-4
python main_custom.py --save_dir=V_T_ours5 --gpu=0 --source_domain=V --target_domain=T --dataset=visda2017 --ours5 --lam=5e-4
