#!/bin/bash

python main_custom.py --save_dir=T_V_baseline3 --gpu=0 --source_domain=B --target_domain=T --dataset=visda2017 --baseline3 --lam=5e-4
python main_custom.py --save_dir=V_T_baseline3 --gpu=0 --source_domain=B --target_domain=V --dataset=visda2017 --baseline3 --lam=5e-4
