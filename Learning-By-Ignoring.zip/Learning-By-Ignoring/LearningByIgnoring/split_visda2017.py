import os
import numpy as np
from pathlib import Path

# def pathSplit():
domains_dir = ['train', 'validation']
abs_, _ = os.path.split(os.path.abspath(__file__))

for dom in domains_dir:
    domain_path = dom + '/images'
    split_dir = abs_ + '/image_list'
    classes = os.listdir(domain_path)
    classes.sort()
    current_class = 0
    for c in classes:
        class_dir = os.path.join(domain_path, c)
        all_img_path = os.listdir(class_dir)

        count = 0
        for img_p in all_img_path:
            remainder = count%38
            if remainder == 0:
                split_dir = os.path.join(split_dir)
                Path(split_dir).mkdir(parents=True, exist_ok=True)
                current_img_path = os.path.join(class_dir, img_p)
                current_img_path = current_img_path + ' ' + str(current_class) + '\n'
                
                #need to make current_img_path path /x/y/z instead of /x\y\z which doesn't read in jupyter notebook
                print('before - current_img_path:', current_img_path)
                current_img_path = current_img_path.replace("\\", "/")
                print('after - current_img_path:', current_img_path)
                
                rand_num = np.random.random()
                if rand_num <= 0.6:
                    split_train_dir = str(split_dir) + '/' + dom + '_train.txt'
                    with open(split_train_dir, 'a') as out:
                        out.write(current_img_path)
                elif rand_num > 0.6 and rand_num <= 0.8:
                    split_val_dir = str(split_dir) + '/' + dom + '_val.txt'
                    with open(split_val_dir, 'a') as out:
                        out.write(current_img_path)
                else:
                    split_test_dir = str(split_dir) + '/' + dom + '_test.txt'
                    with open(split_test_dir, 'a') as out:
                        out.write(current_img_path)
            count += 1
        current_class += 1
