HOW_TO_RUN_CODE:
- The code was run on in Jupyternotebook on Datahub using GPU
- If any questions, please email me at bmc011@ucsd.edu

OBTAIN DATA:
Visda2017_Images: http://ai.bu.edu/visda-2017/#browse
Download visda2017 Data from: https://github.com/VisionLearningGroup/taskcv-2017-public
- Once visda2017 downloaded and unzipped, run split_visda2017.py on it
Formatting Data Path
Place split data into following path: "./temp/data/visda2017"
Files should have following structure in "./temp/data/visda2017"
  - image_list
      - train_test (these contain split data file paths)
      - train_train
      - train_val
      - val_test
      - val_train
      - val_val
  - train
      - image
          - bus
          - car
          - etc.
  - validation
      - image
          - bus
          - car
          - etc.

RUN CODE:
TRAIN OURS2 MODEL
python main_custom.py --save_dir=T_V_ours2 --gpu=0 --source_domain=T --target_domain=V --dataset=visda2017 --ours2 --lam=5e-4 --batch_size=32
TRAIN BASELINE 1 MODEL
python main_custom.py --save_dir=T_V_baseline1 --gpu=0 --source_domain=T --target_domain=V --dataset=visda2017 --baseline1 --lam=5e-4 --batch_size=32

DESCRIPTION OF NOTABLE FILES:
main_custom.py
- does training, testing, validation
main.py
- original file for training, testing, validation on office31 dataset
./temp/data/visda2017/split_visda2017
- splits visda2017 dataset into training, testing, validation
./office31_split_demo/split.py
- splits office31 dataset into training, testing, validation

RESULTS:
OURS2
pretraining domain: T
finetuning domain: V
test accuracy: 0.8305814788226848
test loss: 0.6402021050453186
BASELINE1
pretraining domain: T
finetuning domain: V
test accuracy: 0.826992103374013
tst loss: 0.6562113761901855

